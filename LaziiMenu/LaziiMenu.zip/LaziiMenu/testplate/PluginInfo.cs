﻿namespace laziiMenu
{
    internal class PluginInfo
    {
        public const string GUID = "org.lazii.gorillatag.laziiMenu";
        public const string Name = "lazii Mod Menu";
        public const string Description = "Created by lazii <3";
        public const string Version = "1.0.1";
    }
}
