﻿using static laziiMenu.Menu.Main;

namespace laziiMenu.Mods
{
    internal class Global
    {
        public static void ReturnHome()
        {
            buttonsType = 0;
        }
    }
}
