﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace laziiMenu.Mods
{
    internal class JoinDiscord
    {
        public static void joinDiscord()
        {
            Process.Start("https://discord.gg/ucMTZ97zPe");
        }
    }
}
