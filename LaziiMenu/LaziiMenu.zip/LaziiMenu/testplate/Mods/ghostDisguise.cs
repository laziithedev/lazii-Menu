﻿using System;
using System.Collections.Generic;
using System.Text;
using static laziiMenu.Menu.Main;
using static laziiMenu.Menu.Settings;

namespace laziiMenu.Mods
{
    internal class ghostDisguise
    {
        public static void EnterGhosts()
        {
            buttonsType = 5;
            pageNumber = 0;
        }
    }
}
