﻿using System;
using System.Collections.Generic;
using System.Text;

namespace laziiMenu.Mods
{
    internal class Reconnect
    {
        public static string rejRoom = null;
        public static float rejDebounce = 0f;
    }
}